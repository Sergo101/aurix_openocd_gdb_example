#ifndef _JIMAUTOCONF_H
#define _JIMAUTOCONF_H
/* #undef HAVE_ARPA_INET_H */
/* #undef HAVE_BACKTRACE */
#define HAVE_CFLAG_FNO_ASYNCHRONOUS_UNWIND_TABLES 1
#define HAVE_CFLAG_FNO_UNWIND_TABLES 1
/* #undef HAVE_CRT_EXTERNS_H */
#define HAVE_DECL_ISINF 1
#define HAVE_DECL_ISNAN 1
#define HAVE_DECL_S_IRWXG 1
#define HAVE_DECL_S_IRWXO 1
#define HAVE_DECL_S_IXUSR 1
#define HAVE_DIRENT_H 1
/* #undef HAVE_DLFCN_H */
#define HAVE_DLOPEN_COMPAT 1
#define HAVE_DUP 1
/* #undef HAVE_EXECINFO_H */
#define HAVE_EXECVPE 1
#define HAVE_FCNTL_H 1
/* #undef HAVE_FORK */
#define HAVE_FSTAT64 1
/* #undef HAVE_FSYNC */
/* #undef HAVE_GETADDRINFO */
/* #undef HAVE_GETEUID */
#define HAVE_GMTIME 1
/* #undef HAVE_INET_NTOP */
#define HAVE_ISASCII 1
#define HAVE_ISATTY 1
#define HAVE_LFS 1
/* #undef HAVE_LINK */
#define HAVE_LOCALTIME 1
#define HAVE_LONG_LONG 1
#define HAVE_LSEEK64 1
/* #undef HAVE_LSTAT64 */
#define HAVE_MATH_H 1
#define HAVE_MKDIR_ONE_ARG 1
#define HAVE_MKSTEMP 1
/* #undef HAVE_NETDB_H */
/* #undef HAVE_NETINET_IN_H */
#define HAVE_OPENDIR 1
/* #undef HAVE_PIPE */
/* #undef HAVE_PTY_H */
/* #undef HAVE_READLINK */
/* #undef HAVE_REALPATH */
/* #undef HAVE_REGCOMP */
#define HAVE_RESTRICT 1
/* #undef HAVE_SELECT */
/* #undef HAVE_SHUTDOWN */
/* #undef HAVE_SIGACTION */
#define HAVE_SLEEP 1
/* #undef HAVE_SOCKET */
/* #undef HAVE_SOCKETPAIR */
#define HAVE_STAT64 1
#define HAVE_STDLIB_H 1
#define HAVE_STRINGS_H 1
/* #undef HAVE_STRPTIME */
/* #undef HAVE_STRUCT_FLOCK */
/* #undef HAVE_STRUCT_STAT_ST_MTIM */
/* #undef HAVE_STRUCT_STAT_ST_MTIMESPEC */
/* #undef HAVE_SYMLINK */
/* #undef HAVE_SYSINFO */
/* #undef HAVE_SYSLOG */
#define HAVE_SYSTEM 1
/* #undef HAVE_SYS_SIGLIST */
/* #undef HAVE_SYS_SIGNAME */
/* #undef HAVE_SYS_SOCKET_H */
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYS_TYPES_H 1
/* #undef HAVE_SYS_UN_H */
/* #undef HAVE_TERMIOS_H */
#define HAVE_TIME_H 1
/* #undef HAVE_UALARM */
#define HAVE_UMASK 1
#define HAVE_UNISTD_H 1
#define HAVE_USLEEP 1
/* #undef HAVE_UTIL_H */
/* #undef HAVE_UTIMES */
/* #undef HAVE_WAITPID */
#define HAVE_WINCONSOLE 1
#define HAVE_WINDOWS 1
#define HAVE__FULLPATH 1
/* #undef HAVE__NSGETENVIRON */
#define JIM_DOCS 1
/* #undef JIM_INSTALL */
/* #undef JIM_RANDOMISE_HASH */
#define JIM_REFERENCES 1
#define JIM_REGEXP 1
#define JIM_STATICLIB 1
#define JIM_TAINT 1
/* #undef JIM_UTF8 */
#define JIM_VERSION 84
#define SIZEOF_INT 4
#define SIZEOF_OFF_T 8
#define SIZEOF_TIME_T 8
#define TCL_LIBRARY "C:/testshit/openocd/openocd/out/lib/jim"
#define TCL_PLATFORM_OS "mingw"
#define TCL_PLATFORM_PATH_SEPARATOR ";"
#define TCL_PLATFORM_PLATFORM "windows"
#define _FILE_OFFSET_BITS 64
#define jim_ext_aio 1
#define jim_ext_array 1
#define jim_ext_clock 1
#define jim_ext_eventloop 1
#define jim_ext_exec 1
#define jim_ext_file 1
#define jim_ext_glob 1
#define jim_ext_history 1
#define jim_ext_interp 1
#define jim_ext_json 1
#define jim_ext_jsonencode 1
#define jim_ext_load 1
#define jim_ext_namespace 1
#define jim_ext_nshelper 1
#define jim_ext_oo 1
#define jim_ext_pack 1
#define jim_ext_package 1
#define jim_ext_readdir 1
#define jim_ext_regexp 1
#define jim_ext_stdlib 1
#define jim_ext_tclcompat 1
#define jim_ext_tree 1
#endif
