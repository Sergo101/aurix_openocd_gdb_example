return -code break result
