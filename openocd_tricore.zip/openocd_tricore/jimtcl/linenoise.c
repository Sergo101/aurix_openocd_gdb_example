#line 1 "utf8.h"
#ifndef UTF8_UTIL_H
#define UTF8_UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * UTF-8 utility functions
 *
 * (c) 2010-2019 Steve Bennett <steveb@workware.net.au>
 *
 * See utf8.c for licence details.
 */

#ifndef USE_UTF8
#include <ctype.h>

#define MAX_UTF8_LEN 1

/* No utf-8 support. 1 byte = 1 char */
#define utf8_charcount(S, B) ((B) < 0 ? (int)strlen(S) : (B))
#define utf8_strwidth(S, B) utf8_strlen((S), (B))
#define utf8_tounicode(S, CP) (*(CP) = (unsigned char)*(S), 1)
#define utf8_index(C, I) (I)
#define utf8_dispwidth(C) 1
#define utf8_str_dispwidth(S) (int)strlen(S)
#define utf8_char_bytes(S, B) 1
#define utf8_inspect(S, CP, DW) (*(CP) = (unsigned char)*(S), *(DW) = 1, 1)

#else

/* Note that below the term "character" is used to refer to a grapheme cluster,
 * which may consist of multiple unicode code points.
 * The term "codepoint" refers to a single unicode codepoint
 * that may have a byte length of 1 or more
 */

#define MAX_UTF8_LEN 4

/* If you don't want to use the amalgamation, define UTF8_STATIC to empty
 * to make these functions non-static and put them in a separate .c file.
 */
#ifndef UTF8_STATIC
#define UTF8_STATIC static
#endif

/**
 * Converts the given unicode codepoint (0 - 0x1fffff) to utf-8
 * and stores the result at 'p'.
 *
 * Returns the number of bytes used to store the codepoint.
 */
UTF8_STATIC int utf8_fromunicode(char p[MAX_UTF8_LEN], unsigned uc);

/**
 * Returns the unicode codepoint corresponding to the
 * utf-8 sequence 'str'.
 *
 * Stores the result in *uc and returns the number of bytes
 * consumed.
 *
 * If 'str' is null terminated, then an invalid utf-8 sequence
 * at the end of the string will be returned as individual bytes.
 *
 * If it is not null terminated, the length *must* be checked first.
 *
 * Does not support unicode code points > \u1fffff
 */
UTF8_STATIC int utf8_tounicode(const char *str, int *uc);

/**
 * Returns the byte length of the utf-8 sequence starting with byte 'c'.
 *
 * Returns 1-4, or -1 if this is not a valid start byte.
 */
UTF8_STATIC int utf8_bytelen(int c);

/**
 * Returns the number of characters in the string of the given byte length.
 * If bytelen is -1, the string is assumed to be null terminated.
 *
 * Any bytes which are not part of an valid utf-8
 * sequence are treated as individual characters.
 *
 * Does not support unicode code points > \u1fffff
 */
UTF8_STATIC int utf8_charcount(const char *str, int bytelen);

/**
 * Returns the display width of the given unicode codepoint.
 * This is 1 for normal letters and 0 for combining codepoints and 2 for wide codepoints.
 *
 * In general, use utf8_str_dispwidth() instead of this function as
 * by itself it does not take into account combining characters,
 * which may be part of a grapheme cluster.
 */
UTF8_STATIC int utf8_dispwidth(int cp);

/**
 * Calculates the display width of the null terminates string, 'str'.
 */
UTF8_STATIC int utf8_str_dispwidth(const char *str);

/**
 * Returns the byte index of the given character in the utf-8 string
 * of the given length.
 *
 * This will return the byte length of a utf-8 string
 * if given the char length.
 */
UTF8_STATIC int utf8_index(const char *str, int charindex);

/**
 * Returns the number of bytes used to represent the first character at 'str'
 * of length 'len' bytes. (len < 0 means null-terminated string)
 *
 * A character is a utf-8 encoded base codepoint followed by any number of combining characters,
 * and possibly ZJW-joined characters.
 *
 * If the first character isn't valid UTF-8, it will be treated as a single byte character.
 */
UTF8_STATIC int utf8_char_bytes(const char *str, int len);

/**
 * Like utf8_char_bytes(), but also returns the codepoint in *c and the display width of the character
 * in *dispwidth.
 */
UTF8_STATIC int utf8_inspect(const char *str, int *c, int *dispwidth);

#endif

#ifdef __cplusplus
}
#endif

#endif
#line 1 "utf8.c"
/**
 * UTF-8 utility functions
 *
 * (c) 2010-2026 Steve Bennett <steveb@workware.net.au>
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#ifndef UTF8_UTIL_H
#include "utf8.h"
#endif

#ifdef USE_UTF8
UTF8_STATIC int utf8_fromunicode(char p[MAX_UTF8_LEN], unsigned uc)
{
    if (uc <= 0x7f) {
        *p = uc;
        return 1;
    }
    else if (uc <= 0x7ff) {
        *p++ = 0xc0 | ((uc & 0x7c0) >> 6);
        *p = 0x80 | (uc & 0x3f);
        return 2;
    }
    else if (uc <= 0xffff) {
        *p++ = 0xe0 | ((uc & 0xf000) >> 12);
        *p++ = 0x80 | ((uc & 0xfc0) >> 6);
        *p = 0x80 | (uc & 0x3f);
        return 3;
    }
    /* Note: We silently truncate to 21 bits here: 0x1fffff */
    else {
        *p++ = 0xf0 | ((uc & 0x1c0000) >> 18);
        *p++ = 0x80 | ((uc & 0x3f000) >> 12);
        *p++ = 0x80 | ((uc & 0xfc0) >> 6);
        *p = 0x80 | (uc & 0x3f);
        return 4;
    }
}

UTF8_STATIC int utf8_bytelen(int c)
{
    if ((c & 0x80) == 0) {
        return 1;
    }
    if ((c & 0xe0) == 0xc0) {
        return 2;
    }
    if ((c & 0xf0) == 0xe0) {
        return 3;
    }
    if ((c & 0xf8) == 0xf0) {
        return 4;
    }
    /* Invalid sequence */
    return -1;
}

UTF8_STATIC int utf8_charcount(const char *str, int bytelen)
{
    int chars = 0;
    if (bytelen < 0) {
        bytelen = strlen(str);
    }
    while (bytelen > 0) {
        int n = utf8_char_bytes(str, bytelen);
        if (n > bytelen) {
            /* This is an invalid sequence, so consume what is remaining */
            n = bytelen;
        }
        bytelen -= n;
        str += n;
        chars++;
    }
    return chars;
}

UTF8_STATIC int utf8_index(const char *str, int index)
{
    const char *s = str;
    while (index--) {
        s += utf8_char_bytes(s, -1);
    }
    return s - str;
}

UTF8_STATIC int utf8_tounicode(const char *str, int *uc)
{
    unsigned const char *s = (unsigned const char *)str;

    if (s[0] < 0xc0) {
        *uc = s[0];
        return 1;
    }
    if (s[0] < 0xe0) {
        if ((s[1] & 0xc0) == 0x80) {
            *uc = ((s[0] & ~0xc0) << 6) | (s[1] & ~0x80);
            if (*uc >= 0x80) {
                return 2;
            }
            /* Otherwise this is an invalid sequence */
        }
    }
    else if (s[0] < 0xf0) {
        if (((str[1] & 0xc0) == 0x80) && ((str[2] & 0xc0) == 0x80)) {
            *uc = ((s[0] & ~0xe0) << 12) | ((s[1] & ~0x80) << 6) | (s[2] & ~0x80);
            if (*uc >= 0x800) {
                return 3;
            }
            /* Otherwise this is an invalid sequence */
        }
    }
    else if (s[0] < 0xf8) {
        if (((str[1] & 0xc0) == 0x80) && ((str[2] & 0xc0) == 0x80) && ((str[3] & 0xc0) == 0x80)) {
            *uc = ((s[0] & ~0xf0) << 18) | ((s[1] & ~0x80) << 12) | ((s[2] & ~0x80) << 6) | (s[3] & ~0x80);
            if (*uc >= 0x10000) {
                return 4;
            }
            /* Otherwise this is an invalid sequence */
        }
    }

    /* Invalid sequence, so just return the byte */
    *uc = *s;
    return 1;
}

UTF8_STATIC int utf8_inspect(const char *str, int *c, int *dispwidth)
{
    int n = utf8_tounicode(str, c);
    /* Should this be utf8_str_dispwidth(str, n) instead? */
    *dispwidth = utf8_dispwidth(*c);
    return utf8_char_bytes(str, n);
}

UTF8_STATIC int utf8_str_dispwidth(const char *str)
{
    int width = 0;
    while (*str) {
        int w;
        int c;
        int n = utf8_inspect(str, &c, &w);
        width += w;
        str += n;
    }
    return width;
}

/* Note: The following functions were taken largely as-is from
 * https://github.com/antirez/linenoise.git
 */
static int utf8_is_variation_selector(int cp)
{
    return cp == 0xFE0E || cp == 0xFE0F;  /* Text/emoji style */
}

/* Check if codepoint is a skin tone modifier. */
static int isSkinToneModifier(int cp)
{
    return cp >= 0x1F3FB && cp <= 0x1F3FF;
}

/* Check if codepoint is Zero Width Joiner. */
static int utf8_is_zero_width_joiner(int cp)
{
    return cp == 0x200D;
}

/* Check if codepoint is a Regional Indicator (for flag emoji). */
static int utf8_is_regional_indicator(int cp)
{
    return cp >= 0x1F1E6 && cp <= 0x1F1FF;
}

/* Check if codepoint is a combining mark or other zero-width character. */
static int utf8_is_combining_mark(int cp)
{
    return (cp >= 0x0300 && cp <= 0x036F) ||   /* Combining Diacriticals */
           (cp >= 0x1AB0 && cp <= 0x1AFF) ||   /* Combining Diacriticals Extended */
           (cp >= 0x1DC0 && cp <= 0x1DFF) ||   /* Combining Diacriticals Supplement */
           (cp >= 0x20D0 && cp <= 0x20FF) ||   /* Combining Diacriticals for Symbols */
           (cp >= 0xFE20 && cp <= 0xFE2F);     /* Combining Half Marks */
}

/* Check if codepoint extends the previous character (doesn't start a new grapheme). */
static int utf8_is_grapheme_extend(int cp)
{
    return utf8_is_variation_selector(cp) || isSkinToneModifier(cp) ||
           utf8_is_zero_width_joiner(cp) || utf8_is_combining_mark(cp);
}

/* Note: The following functions are based on code from
 * https://github.com/antirez/linenoise.git
 */
UTF8_STATIC int utf8_char_bytes(const char *str, int len)
{
    /* First we get the current character. Then we look ahead
     * to see if there are any combining characters that follow it, and if so we
     * treat them as part of the same "character".
     */
    int total = 0;

    int c;
    int n = utf8_tounicode(str, &c);
    total += n;
    str += n;

    if (len < 0) {
        len = strlen(str);
    }
    const char *end = str + len;
    int is_ri = utf8_is_regional_indicator(c);

    /* Consume any extending characters that follow. */
    while (str < end) {
        /* Check the next character. */
        n = utf8_tounicode(str, &c);

        if (utf8_is_zero_width_joiner(c) && str + n < end) {
            /* ZWJ: include it and the following character. */
            total += n;
            str += n;
            /* Get the character after ZWJ. */
            n = utf8_tounicode(str, &c);
            total += n;
            str += n;
            continue;  /* Check for more extending after the joined char. */
        } else if (utf8_is_grapheme_extend(c)) {
            /* Variation selector, skin tone, combining mark, etc. */
            total += n;
            str += n;
            continue;
        } else if (is_ri && utf8_is_regional_indicator(c)) {
            /* Second regional indicator for a flag pair. */
            total += n;
            str += n;
            is_ri = 0;  /* Only pair once. */
            continue;
        } else {
            break;
        }
    }

    return total;

}

/* Return the display width of a Unicode codepoint. This is a heuristic
 * that works for most common cases:
 * - Control chars and zero-width: 0 columns
 * - Grapheme-extending chars (VS, skin tone, ZWJ): 0 columns
 * - ASCII printable: 1 column
 * - Wide chars (CJK, emoji, fullwidth): 2 columns
 * - Everything else: 1 column
 *
 * This is not a full wcwidth() implementation, but a minimal heuristic
 * that handles emoji and CJK characters reasonably well. */
UTF8_STATIC int utf8_dispwidth(int cp)
{
    /* Control characters and combining marks: zero width. */
    if (cp < 32 || (cp >= 0x7F && cp < 0xA0)) {
        return 0;
    }
    if (utf8_is_combining_mark(cp)) {
        return 0;
    }

    /* Grapheme-extending characters: zero width.
     * These modify the preceding character rather than taking space. */
    if (utf8_is_variation_selector(cp) || utf8_is_combining_mark(cp) || utf8_is_grapheme_extend(cp)) {
        return 0;
    }

    /* Wide character ranges - these display as 2 columns:
     * - CJK Unified Ideographs and Extensions
     * - Fullwidth forms
     * - Various emoji ranges */
    if (cp >= 0x1100 &&
        (cp <= 0x115F ||                      /* Hangul Jamo */
         cp == 0x2329 || cp == 0x232A ||      /* Angle brackets */
         (cp >= 0x231A && cp <= 0x231B) ||    /* Watch, Hourglass */
         (cp >= 0x23E9 && cp <= 0x23F3) ||    /* Various symbols */
         (cp >= 0x23F8 && cp <= 0x23FA) ||    /* Various symbols */
         (cp >= 0x25AA && cp <= 0x25AB) ||    /* Small squares */
         (cp >= 0x25B6 && cp <= 0x25C0) ||    /* Play/reverse buttons */
         (cp >= 0x25FB && cp <= 0x25FE) ||    /* Squares */
         (cp >= 0x2600 && cp <= 0x26FF) ||    /* Misc Symbols (sun, cloud, etc) */
         (cp >= 0x2700 && cp <= 0x27BF) ||    /* Dingbats (❤, ✂, etc) */
         (cp >= 0x2934 && cp <= 0x2935) ||    /* Arrows */
         (cp >= 0x2B05 && cp <= 0x2B07) ||    /* Arrows */
         (cp >= 0x2B1B && cp <= 0x2B1C) ||    /* Squares */
         cp == 0x2B50 || cp == 0x2B55 ||      /* Star, circle */
         (cp >= 0x2E80 && cp <= 0xA4CF &&
          cp != 0x303F) ||                    /* CJK ... Yi */
         (cp >= 0xAC00 && cp <= 0xD7A3) ||    /* Hangul Syllables */
         (cp >= 0xF900 && cp <= 0xFAFF) ||    /* CJK Compatibility Ideographs */
         (cp >= 0xFE10 && cp <= 0xFE1F) ||    /* Vertical forms */
         (cp >= 0xFE30 && cp <= 0xFE6F) ||    /* CJK Compatibility Forms */
         (cp >= 0xFF00 && cp <= 0xFF60) ||    /* Fullwidth Forms */
         (cp >= 0xFFE0 && cp <= 0xFFE6) ||    /* Fullwidth Signs */
         (cp >= 0x1F1E6 && cp <= 0x1F1FF) ||  /* Regional Indicators (flags) */
         (cp >= 0x1F300 && cp <= 0x1F64F) ||  /* Misc Symbols and Emoticons */
         (cp >= 0x1F680 && cp <= 0x1F6FF) ||  /* Transport and Map Symbols */
         (cp >= 0x1F900 && cp <= 0x1F9FF) ||  /* Supplemental Symbols */
         (cp >= 0x1FA00 && cp <= 0x1FAFF) ||  /* Chess, Extended-A */
         (cp >= 0x20000 && cp <= 0x2FFFF)))   /* CJK Extension B and beyond */
        return 2;

    return 1; /* Default: single width */
}

#endif
#line 1 "stringbuf.h"
#ifndef STRINGBUF_H
#define STRINGBUF_H
/**
 * resizable string buffer supporting utf8 "characters" if USE_UTF8 is defined.
 *
 * Note that here "characters" means utf8 graphemes, which may
 * correspond to more than one codepoint.
 *
 * (c) 2017-2026 Steve Bennett <steveb@workware.net.au>
 *
 * See utf8.c for licence details.
 */
#ifdef __cplusplus
extern "C" {
#endif

/** @file
 * A stringbuf is a resizing, null terminated string buffer.
 *
 * The buffer is reallocated as necessary.
 *
 * In general it is *not* OK to call these functions with a NULL pointer
 * unless stated otherwise.
 *
 * If USE_UTF8 is defined, supports utf8.
 */

/**
 * The stringbuf structure should not be accessed directly.
 * Use the functions below.
 */
typedef struct {
	int remaining;	/**< Allocated, but unused space */
	int last;		/**< Index of the null terminator (and thus the length of the string) */
#ifdef USE_UTF8
	int chars;		/**< Count of characters */
#endif
	char *data;		/**< Allocated memory containing the string or NULL for empty */
} stringbuf;

/**
 * Allocates and returns a new stringbuf with no elements.
 */
stringbuf *sb_alloc(void);

/**
 * Frees a stringbuf.
 * It is OK to call this with NULL.
 */
void sb_free(stringbuf *sb);

/**
 * Returns an allocated copy of the stringbuf
 */
stringbuf *sb_copy(stringbuf *sb);

/**
 * Returns the byte length of the buffer.
 * 
 * Returns 0 for both a NULL buffer and an empty buffer.
 */
static inline int sb_len(stringbuf *sb) {
	return sb->last;
}

/**
 * Returns the utf8 character length of the buffer.
 * 
 * Returns 0 for both a NULL buffer and an empty buffer.
 */
int sb_chars(stringbuf *sb);

/**
 * Appends a null terminated string to the stringbuf
 */
void sb_append(stringbuf *sb, const char *str);

/**
 * Like sb_append() except does not require a null terminated string.
 * The length of 'str' is given as 'len'
 */
void sb_append_len(stringbuf *sb, const char *str, int len);

/**
 * Returns a pointer to the null terminated string in the buffer.
 *
 * Note this pointer only remains valid until the next modification to the
 * string buffer.
 *
 * The returned pointer can be used to update the buffer in-place
 * as long as care is taken to not overwrite the end of the buffer.
 */
static inline char *sb_str(const stringbuf *sb)
{
	return sb->data;
}

/**
 * Inserts the given string *before* (zero-based) byte 'index' in the stringbuf.
 * If index is past the end of the buffer, the string is appended,
 * just like sb_append()
 * len is the length of 'str' in bytes, or -1 to indicate a null terminated string.
 *
 * In utf8 mode, be careful to only insert at the start of a char.
 */
void sb_insert_len(stringbuf *sb, int index, const char *str, int len);

/**
 * Like sb_insert_len() except 'str' is null terminated.
 */
#define sb_insert(SB, I, STR) sb_insert_len(SB, I, STR, -1)

/**
 * Like sb_insert_len() except position is given as a character index instead of a byte index.
 */
void sb_insert_chars(stringbuf *sb, int charindex, const char *str, int len);

/**
 * Delete 'len' bytes in the string at the given byte index.
 *
 * Any bytes past the end of the buffer are ignored.
 * The buffer remains null terminated.
 *
 * If len is -1, deletes to the end of the buffer.
 *
 * In utf8 mode, be careful to only delete whole chars.
 */
void sb_delete(stringbuf *sb, int index, int len);

/**
 * Like sb_delete(), except position and length are given
 * as characters instead of bytes.
 */
void sb_delete_chars(stringbuf *sb, int charindex, int nchars);

/**
 * Clear to an empty buffer.
 */
void sb_clear(stringbuf *sb);

/**
 * Return an allocated copy of buffer and frees 'sb'.
 *
 * If 'sb' is empty, returns an allocated copy of "".
 */
char *sb_to_string(stringbuf *sb);

#ifdef __cplusplus
}
#endif

#endif
#line 1 "stringbuf.c"
/**
 * resizable string buffer
 *
 * (c) 2017-2020 Steve Bennett <steveb@workware.net.au>
 *
 * See utf8.c for licence details.
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <assert.h>

#ifndef STRINGBUF_H
#include "stringbuf.h"
#endif
#ifdef USE_UTF8
#ifndef UTF8_UTIL_H
#include "utf8.h"
#endif
#endif

#define SB_INCREMENT 200

stringbuf *sb_alloc(void)
{
	stringbuf *sb = (stringbuf *)malloc(sizeof(*sb));
	sb->remaining = 0;
	sb->last = 0;
#ifdef USE_UTF8
	sb->chars = 0;
#endif
	sb->data = NULL;

	return(sb);
}

void sb_free(stringbuf *sb)
{
	if (sb) {
		free(sb->data);
	}
	free(sb);
}

static void sb_realloc(stringbuf *sb, int newlen)
{
	sb->data = (char *)realloc(sb->data, newlen);
	sb->remaining = newlen - sb->last;
}

/* Returns the character count, recalculating it if necessary.
 */
#ifdef USE_UTF8
static int sb_get_charlen(stringbuf *sb)
{
	if (sb->chars < 0) {
		sb->chars = utf8_charcount(sb->data, sb->last);
	}
	return sb->chars;
}
#endif

/* Mark the char count as invalid so it can be recalculated when needed. */
static void sb_invalidate_charlen(stringbuf *sb)
{
#ifdef USE_UTF8
	sb->chars = -1;
#else
	(void)sb;
#endif
}

/**
 * Returns the utf8 character length of the buffer.
 *
 * Returns 0 for both a NULL buffer and an empty buffer.
 */
int sb_chars(stringbuf *sb)
{
#ifdef USE_UTF8
	return sb_get_charlen(sb);
#else
	return sb->last;
#endif
}

void sb_append(stringbuf *sb, const char *str)
{
	sb_append_len(sb, str, strlen(str));
}

void sb_append_len(stringbuf *sb, const char *str, int len)
{
	if (sb->remaining < len + 1) {
		sb_realloc(sb, sb->last + len + 1 + SB_INCREMENT);
	}
	memcpy(sb->data + sb->last, str, len);
	sb->data[sb->last + len] = 0;

	sb->last += len;
	sb->remaining -= len;
	sb_invalidate_charlen(sb);
}

char *sb_to_string(stringbuf *sb)
{
	if (sb->data == NULL) {
		/* Return an allocated empty string, not null */
		return strdup("");
	}
	else {
		/* Just return the data and free the stringbuf structure */
		char *pt = sb->data;
		free(sb);
		return pt;
	}
}

/* Insert and delete operations */

/* Moves up all the data at position 'pos' and beyond by 'len' bytes
 * to make room for new data
 *
 * Note: Does *not* recalc char count
 */
static void sb_insert_space(stringbuf *sb, int pos, int len)
{
	assert(pos <= sb->last);

	/* Make sure there is enough space */
	if (sb->remaining < len) {
		sb_realloc(sb, sb->last + len + SB_INCREMENT);
	}
	/* Now move it up */
	memmove(sb->data + pos + len, sb->data + pos, sb->last - pos);
	sb->last += len;
	sb->remaining -= len;
	/* And null terminate */
	sb->data[sb->last] = 0;
}

/**
 * Move down all the data from pos + len, effectively
 * deleting the data at position 'pos' of length 'len'
 *
 * Note: Does *not* recalc char count
 */
static void sb_delete_space(stringbuf *sb, int pos, int len)
{
	assert(pos < sb->last);
	assert(pos + len <= sb->last);

	/* Now move it up */
	memmove(sb->data + pos, sb->data + pos + len, sb->last - pos - len);
	sb->last -= len;
	sb->remaining += len;
	/* And null terminate */
	sb->data[sb->last] = 0;
}

void sb_insert_len(stringbuf *sb, int index, const char *str, int len)
{
	if (len < 0) {
		len = strlen(str);
	}
	if (index >= sb->last) {
		/* Inserting after the end of the list appends. */
		sb_append_len(sb, str, len);
	}
	else {
		sb_insert_space(sb, index, len);
		memcpy(sb->data + index, str, len);
	}
	sb_invalidate_charlen(sb);
}

/**
 * Like sb_insert_len() except position is given as a character index instead of a byte index.
 */
void sb_insert_chars(stringbuf *sb, int charindex, const char *str, int len)
{
	/* Find the byte position of the char index */
#ifdef USE_UTF8
	int pos = utf8_index(sb->data, charindex);
#else
	int pos = charindex;
#endif
	/* And insert the string at that position */
	sb_insert_len(sb, pos, str, len);
}

/**
 * Delete the bytes at index 'index' for length 'len'
 * Has no effect if the index is past the end of the list.
 */
void sb_delete(stringbuf *sb, int index, int len)
{
	if (index < sb->last) {
		char *pos = sb->data + index;
		if (len < 0) {
			len = sb->last;
		}

		sb_delete_space(sb, pos - sb->data, len);
		sb_invalidate_charlen(sb);
	}
}

void sb_delete_chars(stringbuf *sb, int charpos, int nchars)
{
#ifdef USE_UTF8
	if (charpos < sb_get_charlen(sb)) {
		/* Find the byte position of the char index */
		int pos = utf8_index(sb->data, charpos);
		/* Now calculate the byte length of 'nchars' chars at this position */
		int bytelen = utf8_index(sb->data + pos, nchars);
		/* And delete them */
		sb_delete(sb, pos, bytelen);
	}
#else
	/* If we don't have UTF-8 support then just delete the bytes */
	sb_delete(sb, charpos, nchars);
#endif
}

void sb_clear(stringbuf *sb)
{
	if (sb->data) {
		/* Null terminate */
		sb->data[0] = 0;
		sb->last = 0;
#ifdef USE_UTF8
		sb->chars = 0;
#endif
	}
}
#line 1 "linenoise.c"
/* linenoise.c -- guerrilla line editing library against the idea that a
 * line editing lib needs to be 20,000 lines of C code.
 *
 * You can find the latest source code at:
 *
 *   http://github.com/msteveb/linenoise
 *   (forked from http://github.com/antirez/linenoise)
 *
 * Does a number of crazy assumptions that happen to be true in 99.9999% of
 * the 2010 UNIX computers around.
 *
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2010, Salvatore Sanfilippo <antirez at gmail dot com>
 * Copyright (c) 2010, Pieter Noordhuis <pcnoordhuis at gmail dot com>
 * Copyright (c) 2011, Steve Bennett <steveb at workware dot net dot au>
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *  *  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *  *  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * References:
 * - http://invisible-island.net/xterm/ctlseqs/ctlseqs.html
 * - http://www.3waylabs.com/nw/WWW/products/wizcon/vt220.html
 *
 * Bloat:
 * - Completion?
 *
 * Unix/termios
 * ------------
 * List of escape sequences used by this program, we do everything just
 * a few sequences. In order to be so cheap we may have some
 * flickering effect with some slow terminal, but the lesser sequences
 * the more compatible.
 *
 * EL (Erase Line)
 *    Sequence: ESC [ 0 K
 *    Effect: clear from cursor to end of line
 *
 * CUF (CUrsor Forward)
 *    Sequence: ESC [ n C
 *    Effect: moves cursor forward n chars
 *
 * CR (Carriage Return)
 *    Sequence: \r
 *    Effect: moves cursor to column 1
 *
 * The following are used to clear the screen: ESC [ H ESC [ 2 J
 * This is actually composed of two sequences:
 *
 * cursorhome
 *    Sequence: ESC [ H
 *    Effect: moves the cursor to upper left corner
 *
 * ED2 (Clear entire screen)
 *    Sequence: ESC [ 2 J
 *    Effect: clear the whole screen
 *
 * == For highlighting control characters, we also use the following two ==
 * SO (enter StandOut)
 *    Sequence: ESC [ 7 m
 *    Effect: Uses some standout mode such as reverse video
 *
 * SE (Standout End)
 *    Sequence: ESC [ 0 m
 *    Effect: Exit standout mode
 *
 * == Only used if TIOCGWINSZ fails ==
 * DSR/CPR (Report cursor position)
 *    Sequence: ESC [ 6 n
 *    Effect: reports current cursor position as ESC [ NNN ; MMM R
 *
 * == Only used in multiline mode ==
 * CUU (Cursor Up)
 *    Sequence: ESC [ n A
 *    Effect: moves cursor up n chars.
 *
 * CUD (Cursor Down)
 *    Sequence: ESC [ n B
 *    Effect: moves cursor down n chars.
 *
 * win32/console
 * -------------
 * If __MINGW32__ is defined, the win32 console API is used.
 * This could probably be made to work for the msvc compiler too.
 * This support based in part on work by Jon Griffiths.
 */

#ifdef _WIN32 /* Windows platform, either MinGW or Visual Studio (MSVC) */
#include <windows.h>
#include <fcntl.h>
#define USE_WINCONSOLE
#ifdef __MINGW32__
#define HAVE_UNISTD_H
#endif
#else
#include <termios.h>
#include <sys/ioctl.h>
#include <poll.h>
#define USE_TERMIOS
#define HAVE_UNISTD_H
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>

#if defined(_WIN32) && !defined(__MINGW32__)
/* Microsoft headers don't like old POSIX names */
#define strdup _strdup
#define snprintf _snprintf
#endif

#include "linenoise.h"
#ifndef STRINGBUF_H
#include "stringbuf.h"
#endif
#ifndef UTF8_UTIL_H
#include "utf8.h"
#endif

#define LINENOISE_DEFAULT_HISTORY_MAX_LEN 100

/* ctrl('A') -> 0x01 */
#define ctrl(C) ((C) - '@')
/* meta('a') ->  -0xe1 */
#define meta(C) -((C) | 0x80)

/* Use -ve numbers here to co-exist with normal unicode chars */
enum {
    SPECIAL_NONE,
    /* don't use -1 here since that indicates error */
    SPECIAL_UP = -20,
    SPECIAL_DOWN = -21,
    SPECIAL_LEFT = -22,
    SPECIAL_RIGHT = -23,
    SPECIAL_DELETE = -24,
    SPECIAL_HOME = -25,
    SPECIAL_END = -26,
    SPECIAL_INSERT = -27,
    SPECIAL_PAGE_UP = -28,
    SPECIAL_PAGE_DOWN = -29,

    /* Some handy names for other special keycodes */
    CHAR_ESCAPE = 27,
    CHAR_DELETE = 127,
};

static int history_max_len = LINENOISE_DEFAULT_HISTORY_MAX_LEN;
static int history_len = 0;
static int history_index = 0;
static char **history = NULL;

/* Structure to contain the status of the current (being edited) line */
struct current {
    stringbuf *buf; /* Current buffer. Always null terminated */
    int pos;    /* Cursor position, measured in chars */
    int cols;   /* Size of the window, in chars */
    int nrows;  /* How many rows are being used in multiline mode (>= 1) */
    int rpos;   /* The current row containing the cursor - multiline mode only */
    int colsright; /* refreshLine() cached cols for insert_char() optimisation */
    int colsleft;  /* refreshLine() cached cols for remove_char() optimisation */
    const char *prompt;
    stringbuf *capture; /* capture buffer, or NULL for none. Always null terminated */
    stringbuf *output;  /* used only during refreshLine() - output accumulator */
#if defined(USE_TERMIOS)
    int fdin;      /* Terminal input fd */
    int fdout;     /* Terminal output fd */
    int pending; /* pending char fd_read_char() */
#elif defined(USE_WINCONSOLE)
    HANDLE outh; /* Console output handle */
    HANDLE inh; /* Console input handle */
    int rows;   /* Screen rows */
    int x;      /* Current column during output */
    int y;      /* Current row */
#ifdef USE_UTF8
    #define UBUF_MAX_CHARS 132
    WORD ubuf[UBUF_MAX_CHARS + 1];  /* Accumulates utf16 output - one extra for final surrogate pairs */
    int ubuflen;      /* length used in ubuf */
    int ubufcols;     /* how many columns are represented by the chars in ubuf? */
#endif
#endif
};

static int fd_read(struct current *current);
static int getWindowSize(struct current *current);
static void cursorDown(struct current *current, int n);
static void cursorUp(struct current *current, int n);
static void eraseEol(struct current *current);
static void refreshLine(struct current *current);
static void refreshLineAlt(struct current *current, const char *prompt, const char *buf, int cursor_pos);
static void setCursorPos(struct current *current, int x);
static void setOutputHighlight(struct current *current, const int *props, int nprops);
static void set_current(struct current *current, const char *str);

static int fd_isatty(struct current *current)
{
#ifdef USE_TERMIOS
    return isatty(current->fdin);
#else
    (void)current;
    return 0;
#endif
}

void linenoiseHistoryFree(void) {
    if (history) {
        int j;

        for (j = 0; j < history_len; j++)
            free(history[j]);
        free(history);
        history = NULL;
        history_len = 0;
    }
}

typedef enum {
    EP_START,   /* looking for ESC */
    EP_ESC,     /* looking for [ */
    EP_DIGITS,  /* parsing digits */
    EP_PROPS,   /* parsing digits or semicolons */
    EP_END,     /* ok */
    EP_ERROR,   /* error */
} ep_state_t;

struct esc_parser {
    ep_state_t state;
    int props[5];   /* properties are stored here */
    int maxprops;   /* size of the props[] array */
    int numprops;   /* number of properties found */
    int termchar;   /* terminator char, or 0 for any alpha */
    int current;    /* current (partial) property value */
};

/**
 * Initialise the escape sequence parser at *parser.
 *
 * If termchar is 0 any alpha char terminates ok. Otherwise only the given
 * char terminates successfully.
 * Run the parser state machine with calls to parseEscapeSequence() for each char.
 */
static void initParseEscapeSeq(struct esc_parser *parser, int termchar)
{
    parser->state = EP_START;
    parser->maxprops = sizeof(parser->props) / sizeof(*parser->props);
    parser->numprops = 0;
    parser->current = 0;
    parser->termchar = termchar;
}

/**
 * Pass character 'ch' into the state machine to parse:
 *   'ESC' '[' <digits> (';' <digits>)* <termchar>
 *
 * The first character must be ESC.
 * Returns the current state. The state machine is done when it returns either EP_END
 * or EP_ERROR.
 *
 * On EP_END, the "property/attribute" values can be read from parser->props[]
 * of length parser->numprops.
 */
static int parseEscapeSequence(struct esc_parser *parser, int ch)
{
    switch (parser->state) {
        case EP_START:
            parser->state = (ch == '\x1b') ? EP_ESC : EP_ERROR;
            break;
        case EP_ESC:
            parser->state = (ch == '[') ? EP_DIGITS : EP_ERROR;
            break;
        case EP_PROPS:
            if (ch == ';') {
                parser->state = EP_DIGITS;
donedigits:
                if (parser->numprops + 1 < parser->maxprops) {
                    parser->props[parser->numprops++] = parser->current;
                    parser->current = 0;
                }
                break;
            }
            /* fall through */
        case EP_DIGITS:
            if (ch >= '0' && ch <= '9') {
                parser->current = parser->current * 10 + (ch - '0');
                parser->state = EP_PROPS;
                break;
            }
            /* must be terminator */
            if (parser->termchar != ch) {
                if (parser->termchar != 0 || !((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))) {
                    parser->state = EP_ERROR;
                    break;
                }
            }
            parser->state = EP_END;
            goto donedigits;
        case EP_END:
            parser->state = EP_ERROR;
            break;
        case EP_ERROR:
            break;
    }
    return parser->state;
}

/*#define DEBUG_REFRESHLINE*/

#ifdef DEBUG_REFRESHLINE
#define DRL(ARGS...) fprintf(dfh, ARGS)
static FILE *dfh;

/* debug output - codepoint or control char */
static void DRL_CODEPOINT(int ch)
{
    if (ch < ' ') {
        DRL("^%c", ch + '@');
    }
    else if (ch > 127) {
        DRL("\\u%04x", ch);
    }
    else {
        DRL("%c", ch);
    }
}

/* debug output - null terminated string */
static void DRL_STR(const char *str)
{
    while (*str) {
        int ch;
        int n = utf8_tounicode(str, &ch);
        str += n;
        DRL_CODEPOINT(ch);
    }
}

/* debug output - first character (grapheme cluster) of str */
static void DRL_CHAR(const char *str)
{
    int bytes = utf8_char_bytes(str, -1);
    while (bytes) {
        int ch;
        int n = utf8_tounicode(str, &ch);
        DRL_CODEPOINT(ch);
        bytes -= n;
        str += n;
    }
}
#else
#define DRL(...)
#define DRL_CODEPOINT(ch)
#define DRL_STR(str)
#define DRL_CHAR(str)
#endif

#if defined(USE_WINCONSOLE)
#include "linenoise-win32.c"
#endif

#if defined(USE_TERMIOS)
static void linenoiseAtExit(void);
static struct termios orig_termios; /* in order to restore at exit */
static int rawmode = 0; /* for atexit() function to check if restore is needed*/
static int atexit_registered = 0; /* register atexit just 1 time */

static const char *unsupported_term[] = {"dumb","cons25","emacs",NULL};

static int isUnsupportedTerm(void) {
    char *term = getenv("TERM");

    if (term) {
        int j;
        for (j = 0; unsupported_term[j]; j++) {
            if (strcmp(term, unsupported_term[j]) == 0) {
                return 1;
            }
        }
    }
    return 0;
}

static int enableRawMode(struct current *current) {
    struct termios raw;

    current->fdin = STDIN_FILENO;
    current->fdout = STDOUT_FILENO;
    current->cols = 0;

    if (getenv("LINENOISE_ASSUME_TTY")) {
        /* Set no buffering on stdout */
        setvbuf(stdout, NULL, _IONBF, 0);
        rawmode = 2;
        return 0;
    }

    if (!isatty(current->fdin) || isUnsupportedTerm() ||
        tcgetattr(current->fdin, &orig_termios) == -1) {
fatal:
        errno = ENOTTY;
        return -1;
    }

    if (!atexit_registered) {
        atexit(linenoiseAtExit);
        atexit_registered = 1;
    }

    raw = orig_termios;  /* modify the original mode */
    /* input modes: no break, no CR to NL, no parity check, no strip char,
     * no start/stop output control. */
    raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    /* output modes - actually, no need to disable post processing */
    /*raw.c_oflag &= ~(OPOST);*/
    /* control modes - set 8 bit chars */
    raw.c_cflag |= (CS8);
    /* local modes - choing off, canonical off, no extended functions,
     * no signal chars (^Z,^C) */
    raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
    /* control chars - set return condition: min number of bytes and timer.
     * We want read to return every single byte, without timeout. */
    raw.c_cc[VMIN] = 1; raw.c_cc[VTIME] = 0; /* 1 byte, no timer */

    /* put terminal in raw mode. Because we aren't changing any output
     * settings we don't need to use TCSADRAIN and I have seen that hang on
     * OpenBSD when running under a pty
     */
    if (tcsetattr(current->fdin,TCSANOW,&raw) < 0) {
        goto fatal;
    }
    rawmode = 1;
    return 0;
}

static void disableRawMode(struct current *current) {
    /* Don't even check the return value as it's too late. */
    if (rawmode == 1) {
        tcsetattr(current->fdin,TCSANOW,&orig_termios);
    }
    rawmode = 0;
}

/* At exit we'll try to fix the terminal to the initial conditions. */
static void linenoiseAtExit(void) {
    if (rawmode == 1) {
        tcsetattr(STDIN_FILENO, TCSANOW, &orig_termios);
    }
    linenoiseHistoryFree();
}

/* gcc/glibc insists that we care about the return code of write!
 * Clarification: This means that a void-cast like "(void) (EXPR)"
 * does not work.
 */
#define IGNORE_RC(EXPR) if (EXPR) {}

/**
 * Output bytes directly, or accumulate output (if current->output is set)
 */
static void outputChars(struct current *current, const char *buf, int len)
{
    if (len < 0) {
        len = strlen(buf);
    }
    if (current->output) {
        sb_append_len(current->output, buf, len);
    }
    else {
        IGNORE_RC(write(current->fdout, buf, len));
    }
}

/* Like outputChars, but using printf-style formatting
 */
static void outputFormatted(struct current *current, const char *format, ...)
{
    va_list args;
    char buf[64];
    int n;

    va_start(args, format);
    n = vsnprintf(buf, sizeof(buf), format, args);
    /* This will never happen because we are sure to use outputFormatted() only for short sequences */
    assert(n < (int)sizeof(buf));
    va_end(args);
    outputChars(current, buf, n);
}

static void cursorToLeft(struct current *current)
{
    outputChars(current, "\r", -1);
}

static void setOutputHighlight(struct current *current, const int *props, int nprops)
{
    outputChars(current, "\x1b[", -1);
    while (nprops--) {
        outputFormatted(current, "%d%c", *props, (nprops == 0) ? 'm' : ';');
        props++;
    }
}

static void eraseEol(struct current *current)
{
    outputChars(current, "\x1b[0K", -1);
}

static void setCursorPos(struct current *current, int x)
{
    if (x == 0) {
        cursorToLeft(current);
    }
    else {
        outputFormatted(current, "\r\x1b[%dC", x);
    }
}

static void cursorUp(struct current *current, int n)
{
    if (n) {
        outputFormatted(current, "\x1b[%dA", n);
    }
}

static void cursorDown(struct current *current, int n)
{
    if (n) {
        outputFormatted(current, "\x1b[%dB", n);
    }
}

void linenoiseClearScreen(void)
{
    IGNORE_RC(write(STDOUT_FILENO, "\x1b[H\x1b[2J", 7));
}

/**
 * Reads a char from 'current->fd', waiting at most 'timeout' milliseconds.
 *
 * A timeout of -1 means to wait forever.
 *
 * Returns -1 if no char is received within the time or an error occurs.
 */
static int fd_read_char(struct current *current, int timeout)
{
    struct pollfd p;
    unsigned char c;

    if (current->pending) {
        c = current->pending;
        current->pending = 0;
        return c;
    }

    p.fd = current->fdin;
    p.events = POLLIN;

    if (poll(&p, 1, timeout) == 0) {
        /* timeout */
        return -1;
    }
    if (read(current->fdin, &c, 1) != 1) {
        return -1;
    }
    return c;
}

/**
 * Reads a complete utf-8 character
 * and returns the unicode value, or -1 on error.
 */
static int fd_read(struct current *current)
{
#ifdef USE_UTF8
    char buf[MAX_UTF8_LEN];
    int n;
    int i;
    int c;

    if (current->pending) {
        buf[0] = current->pending;
        current->pending = 0;
    }
    else if (read(current->fdin, &buf[0], 1) != 1) {
        return -1;
    }
    n = utf8_bytelen(buf[0]);
    if (n < 1) {
        return -1;
    }
    for (i = 1; i < n; i++) {
        if (read(current->fdin, &buf[i], 1) != 1) {
            return -1;
        }
    }
    /* decode and return the character */
    utf8_tounicode(buf, &c);
    return c;
#else
    return fd_read_char(current, -1);
#endif
}


/**
 * Stores the current cursor column in '*cols'.
 * Returns 1 if OK, or 0 if failed to determine cursor pos.
 */
static int queryCursor(struct current *current, int* cols)
{
    struct esc_parser parser;
    int ch;
    /* Unfortunately we don't have any persistent state, so assume
     * a process will only ever interact with one terminal at a time.
     */
    static int query_cursor_failed;

    if (query_cursor_failed) {
        /* If it ever fails, don't try again */
        return 0;
    }

    /* Should not be buffering this output, it needs to go immediately */
    assert(current->output == NULL);

    /* control sequence - report cursor location */
    outputChars(current, "\x1b[6n", -1);

    /* Parse the response: ESC [ rows ; cols R */
    initParseEscapeSeq(&parser, 'R');
    while ((ch = fd_read_char(current, 100)) > 0) {
        switch (parseEscapeSequence(&parser, ch)) {
            default:
                continue;
            case EP_END:
                if (parser.numprops == 2 && parser.props[1] < 1000) {
                    *cols = parser.props[1];
                    return 1;
                }
                break;
            case EP_ERROR:
                /* Push back the character that caused the error */
                current->pending = ch;
                break;
        }
        /* failed */
        break;
    }
    query_cursor_failed = 1;
    return 0;
}

/**
 * Updates current->cols with the current window size (width)
 */
static int getWindowSize(struct current *current)
{
    struct winsize ws;

    const char *linenoise_cols = getenv("LINENOISE_COLS");
    if (linenoise_cols) {
        /* Just trust what we are given for testing */
        current->cols = atoi(linenoise_cols);
        return 0;
    }

    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col != 0) {
        current->cols = ws.ws_col;
        return 0;
    }

    /* Failed to query the window size. Perhaps we are on a serial terminal.
     * Try to query the width by sending the cursor as far to the right
     * and reading back the cursor position.
     * Note that this is only done once per call to linenoise rather than
     * every time the line is refreshed for efficiency reasons.
     *
     * In more detail, we:
     * (a) request current cursor position,
     * (b) move cursor far right,
     * (c) request cursor position again,
     * (d) at last move back to the old position.
     * This gives us the width without messing with the externally
     * visible cursor position.
     */

    if (current->cols == 0) {
        int here;

        /* If anything fails => default 80 */
        current->cols = 80;

        /* (a) */
        if (queryCursor (current, &here)) {
            /* (b) */
            setCursorPos(current, 999);

            /* (c). Note: If (a) succeeded, then (c) should as well.
             * For paranoia we still check and have a fallback action
             * for (d) in case of failure..
             */
            if (queryCursor (current, &current->cols)) {
                /* (d) Reset the cursor back to the original location. */
                if (current->cols > here) {
                    setCursorPos(current, here);
                }
            }
        }
    }

    return 0;
}

/**
 * If CHAR_ESCAPE was received, reads subsequent
 * chars to determine if this is a known special key.
 *
 * Returns SPECIAL_NONE if unrecognised, or -1 if EOF.
 *
 * If no additional char is received within a short time,
 * CHAR_ESCAPE is returned.
 */
static int check_special(struct current *current)
{
    int c = fd_read_char(current, 50);
    int c2;

    if (c < 0) {
        return CHAR_ESCAPE;
    }
    else if (c >= 'a' && c <= 'z') {
        /* esc-a => meta-a */
        return meta(c);
    }

    c2 = fd_read_char(current, 50);
    if (c2 < 0) {
        return c2;
    }
    if (c == '[' || c == 'O') {
        /* Potential arrow key */
        switch (c2) {
            case 'A':
                return SPECIAL_UP;
            case 'B':
                return SPECIAL_DOWN;
            case 'C':
                return SPECIAL_RIGHT;
            case 'D':
                return SPECIAL_LEFT;
            case 'F':
                return SPECIAL_END;
            case 'H':
                return SPECIAL_HOME;
        }
    }
    if (c == '[' && c2 >= '1' && c2 <= '8') {
        /* extended escape */
        c = fd_read_char(current, 50);
        if (c == '~') {
            switch (c2) {
                case '2':
                    return SPECIAL_INSERT;
                case '3':
                    return SPECIAL_DELETE;
                case '5':
                    return SPECIAL_PAGE_UP;
                case '6':
                    return SPECIAL_PAGE_DOWN;
                case '7':
                    return SPECIAL_HOME;
                case '8':
                    return SPECIAL_END;
            }
        }
        while (c != -1 && c != '~') {
            /* .e.g \e[12~ or '\e[11;2~   discard the complete sequence */
            c = fd_read_char(current, 50);
        }
    }

    return SPECIAL_NONE;
}
#endif

static void clearOutputHighlight(struct current *current)
{
    int nohighlight = 0;
    setOutputHighlight(current, &nohighlight, 1);
}

static void outputControlChar(struct current *current, char ch)
{
    int reverse = 7;
    setOutputHighlight(current, &reverse, 1);
    outputChars(current, "^", 1);
    outputChars(current, &ch, 1);
    clearOutputHighlight(current);
}

#ifndef utf8_getchars
static int utf8_getchars(char *buf, int c)
{
#ifdef USE_UTF8
    return utf8_fromunicode(buf, c);
#else
    *buf = c;
    return 1;
#endif
}
#endif

/* Returns the length (in bytes) of the character at the given character position in current->buf,
 * and stores the byte offset in *offset. If there is no character at that position, returns -1.
 * and *offset is unchanged.
 */
static int get_char_offset(struct current *current, int pos, int *offset)
{
    if (pos >= 0 && pos < sb_chars(current->buf)) {
        int i = utf8_index(sb_str(current->buf), pos);
        int n = utf8_char_bytes(sb_str(current->buf) + i, -1);
        *offset = i;
        return n;
    }
    return -1;
}

/**
 * Returns the unicode character at the given character position in current->buf,
 * or -1 if none.
 *
 * Note that this only returns the first codepoint of a grapheme cluster (character)
 *
 */
static int get_char(struct current *current, int pos)
{
    int offset;
    if (get_char_offset(current, pos, &offset) >= 0) {
        int c;
        (void)utf8_tounicode(sb_str(current->buf) + offset, &c);
        return c;
    }
    return -1;
}

#ifndef NO_COMPLETION
static linenoiseCompletionCallback *completionCallback = NULL;
static void *completionUserdata = NULL;
static int showhints = 1;
static linenoiseHintsCallback *hintsCallback = NULL;
static linenoiseFreeHintsCallback *freeHintsCallback = NULL;
static void *hintsUserdata = NULL;

static void beep(void) {
#ifdef USE_TERMIOS
    fprintf(stderr, "\x7");
    fflush(stderr);
#endif
}

static void freeCompletions(linenoiseCompletions *lc) {
    size_t i;
    for (i = 0; i < lc->len; i++)
        free(lc->cvec[i]);
    free(lc->cvec);
}

static int completeLine(struct current *current) {
    linenoiseCompletions lc = { 0, NULL };
    int c = 0;

    completionCallback(sb_str(current->buf),&lc,completionUserdata);
    if (lc.len == 0) {
        beep();
    } else {
        size_t stop = 0, i = 0;

        while(!stop) {
            /* Show completion or original buffer */
            if (i < lc.len) {
                int display_cols = utf8_str_dispwidth(lc.cvec[i]);
                refreshLineAlt(current, current->prompt, lc.cvec[i], display_cols);
            } else {
                refreshLine(current);
            }

            c = fd_read(current);
            if (c == -1) {
                break;
            }

            switch(c) {
                case '\t': /* tab */
                    i = (i+1) % (lc.len+1);
                    if (i == lc.len) beep();
                    break;
                case CHAR_ESCAPE: /* escape */
                    /* Re-show original buffer */
                    if (i < lc.len) {
                        refreshLine(current);
                    }
                    stop = 1;
                    break;
                default:
                    /* Update buffer and return */
                    if (i < lc.len) {
                        set_current(current,lc.cvec[i]);
                    }
                    stop = 1;
                    break;
            }
        }
    }

    freeCompletions(&lc);
    return c; /* Return last read character */
}

/* Register a callback function to be called for tab-completion.
   Returns the prior callback so that the caller may (if needed)
   restore it when done. */
linenoiseCompletionCallback * linenoiseSetCompletionCallback(linenoiseCompletionCallback *fn, void *userdata) {
    linenoiseCompletionCallback * old = completionCallback;
    completionCallback = fn;
    completionUserdata = userdata;
    return old;
}

void linenoiseAddCompletion(linenoiseCompletions *lc, const char *str) {
    lc->cvec = (char **)realloc(lc->cvec,sizeof(char*)*(lc->len+1));
    lc->cvec[lc->len++] = strdup(str);
}

void linenoiseSetHintsCallback(linenoiseHintsCallback *callback, void *userdata)
{
    hintsCallback = callback;
    hintsUserdata = userdata;
}

void linenoiseSetFreeHintsCallback(linenoiseFreeHintsCallback *callback)
{
    freeHintsCallback = callback;
}

#endif

/* Like utf8_str_dispwidth, but only for the first charlen characters of str.
 */
static int utf8_str_dispwidth_len(const char *str, int charlen)
{
    int width = 0;
    while (*str && charlen) {
        int w;
        int c;
        int n = utf8_inspect(str, &c, &w);
        width += w;
        str += n;
        charlen--;
    }
    return width;
}


static const char *reduceSingleBuf(const char *buf, int availcols, int *cursor_pos)
{
    /* We have availcols columns available.
     * If necessary, strip chars off the front of buf until *cursor_pos
     * fits within availcols
     */
    int new_cursor_pos = *cursor_pos;
    const char *pt;

    DRL("reduceSingleBuf: availcols=%d, cursor_pos=%d\n", availcols, *cursor_pos);
    /* Debug print the initial state */
    int col = 0;
    int pos = 0;
    for (pt = buf; *pt; ) {
        int w;
        int c;
        if (pos == *cursor_pos) {
            DRL("<cursor>");
        }
        DRL_CHAR(pt);
        int n = utf8_inspect(pt, &c, &w);
        if (col < availcols && col + w >= availcols) {
            DRL("<avail>");
        }
        col += w;
        pt += n;
    }
    DRL("\n");

    pt = buf;
    while (*pt) {
        /* Find the column of the cursor position */
        int cursor_col = utf8_str_dispwidth_len(buf, new_cursor_pos);
        DRL("cursor_col of pos=%d is %d vs availcols=%d\n", new_cursor_pos, cursor_col, availcols);
        if (cursor_col > availcols) {
            /* Cursor is not visible, so strip one char off the beginning */
            int w;
            int c;
            int n = utf8_inspect(pt, &c, &w);
            DRL("remove char from front of buffer: ");
            DRL_CHAR(pt);
            DRL("\n");
            pt += n;
            /* and adjust the apparent cursor position */
            new_cursor_pos--;
            continue;
        }
        /* done */
        break;
    }
    DRL("<snip>");
    DRL_STR(pt);
    DRL("\nafter reduce, new_cursor_pos=%d\n", new_cursor_pos);

    /* Done, now new_cursor_pos contains the adjusted cursor position
     * and buf points to he adjusted start
     */
    *cursor_pos = new_cursor_pos;
    return pt;
}

static int mlmode = 0;

void linenoiseSetMultiLine(int enableml)
{
    mlmode = enableml;
}

/* Helper of refreshSingleLine() and refreshMultiLine() to show hints
 * to the right of the prompt.
 * Returns 1 if a hint was shown, or 0 if not
 * If 'display' is 0, does no output. Just returns the appropriate return code.
 */
static int refreshShowHints(struct current *current, const char *buf, int availcols, int display)
{
    int rc = 0;
    if (showhints && hintsCallback && availcols > 0) {
        int bold = 0;
        int color = -1;
        char *hint = hintsCallback(buf, &color, &bold, hintsUserdata);
        if (hint) {
            rc = 1;
            if (display) {
                const char *pt;
                if (bold == 1 && color == -1) color = 37;
                if (bold || color > 0) {
                    int props[3] = { bold, color, 49 }; /* bold, color, fgnormal */
                    setOutputHighlight(current, props, 3);
                }
                DRL("<hint bold=%d,color=%d>", bold, color);
                pt = hint;
                while (*pt) {
                    int width;
                    int c;
                    int n = utf8_inspect(pt, &c, &width);

                    if (width >= availcols) {
                        DRL("<hinteol>");
                        break;
                    }
                    DRL_CHAR(pt);

                    availcols -= width;
                    outputChars(current, pt, n);
                    pt += n;
                }
                if (bold || color > 0) {
                    clearOutputHighlight(current);
                }
                /* Call the function to free the hint returned. */
                if (freeHintsCallback) freeHintsCallback(hint, hintsUserdata);
            }
        }
    }
    return rc;
}

#ifdef USE_TERMIOS
static void refreshStart(struct current *current)
{
    /* We accumulate all output here */
    assert(current->output == NULL);
    current->output = sb_alloc();
}

static void refreshEnd(struct current *current)
{
    /* Output everything at once */
    IGNORE_RC(write(current->fdout, sb_str(current->output), sb_len(current->output)));
    sb_free(current->output);
    current->output = NULL;
}

static void refreshStartChars(struct current *current)
{
    (void)current;
}

static void refreshNewline(struct current *current)
{
    DRL("<nl>");
    outputChars(current, "\r\n", 2);
}

static void refreshEndChars(struct current *current)
{
    (void)current;
}
#endif

static void refreshLineAlt(struct current *current, const char *prompt, const char *buf, int cursor_pos)
{
    int i;
    const char *pt;
    int displaycol;
    int displayrow;
    int visible;
    int currentpos;
    int notecursor;
    int cursorcol = 0;
    int cursorrow = 0;
    int hint;
    struct esc_parser parser;

#ifdef DEBUG_REFRESHLINE
    dfh = fopen("linenoise.debuglog", "a");
#endif

    /* Should intercept SIGWINCH. For now, just get the size every time */
    getWindowSize(current);

    refreshStart(current);

    DRL("wincols=%d, cursor_pos=%d, nrows=%d, rpos=%d\n", current->cols, cursor_pos, current->nrows, current->rpos);

    /* Here is the plan:
     * (a) move the the bottom row, going down the appropriate number of lines
     * (b) move to beginning of line and erase the current line
     * (c) go up one line and do the same, until we have erased up to the first row
     * (d) output the prompt, counting cols and rows, taking into account escape sequences
     * (e) output the buffer, counting cols and rows
     *   (e') when we hit the current pos, save the cursor position
     * (f) move the cursor to the saved cursor position
     * (g) save the current cursor row and number of rows
     */

    /* (a) - The cursor is currently at row rpos */
    cursorDown(current, current->nrows - current->rpos - 1);
    DRL("<cud=%d>", current->nrows - current->rpos - 1);

    /* (b), (c) - Erase lines upwards until we get to the first row */
    for (i = 0; i < current->nrows; i++) {
        if (i) {
            DRL("<cup>");
            cursorUp(current, 1);
        }
        DRL("<clearline>");
        cursorToLeft(current);
        eraseEol(current);
    }
    DRL("\n");

    /* (d) First output the prompt. control sequences don't take up display space */
    pt = prompt;
    displaycol = 0; /* current display column */
    displayrow = 0; /* current display row */
    visible = 1;

    refreshStartChars(current);

    while (*pt) {
        int width;
        int ch;
        int n = utf8_inspect(pt, &ch, &width);

        if (visible && ch == CHAR_ESCAPE) {
            /* The start of an escape sequence, so not visible */
            visible = 0;
            initParseEscapeSeq(&parser, 'm');
            DRL("<esc-seq-start>");
        }

        if (ch == '\n' || ch == '\r') {
            /* treat both CR and NL the same and force wrap */
            refreshNewline(current);
            displaycol = 0;
            displayrow++;
        }
        else {
            if (!visible) {
                width = 0;
            }

            displaycol += width;
            if (displaycol >= current->cols) {
                /* need to wrap to the next line because of newline or if it doesn't fit
                 * XXX this is a problem in single line mode
                 */
                refreshNewline(current);
                displaycol = width;
                displayrow++;
            }

            DRL_CHAR(pt);
#ifdef USE_WINCONSOLE
            if (visible) {
                outputChars(current, pt, n);
            }
#else
            outputChars(current, pt, n);
#endif
        }
        pt += n;

        if (!visible) {
            switch (parseEscapeSequence(&parser, ch)) {
                case EP_END:
                    visible = 1;
                    setOutputHighlight(current, parser.props, parser.numprops);
                    DRL("<esc-seq-end,numprops=%d>", parser.numprops);
                    break;
                case EP_ERROR:
                    DRL("<esc-seq-err>");
                    visible = 1;
                    break;
            }
        }
    }

    /* Now we are at the first line with all lines erased */
    DRL("\nafter prompt: displaycol=%d, displayrow=%d\n", displaycol, displayrow);


    /* (e) output the buffer, counting cols and rows */
    if (mlmode == 0) {
        /* In this mode we may need to trim chars from the start of the buffer until the
         * cursor fits in the window.
         */
        pt = reduceSingleBuf(buf, current->cols - displaycol, &cursor_pos);
    }
    else {
        pt = buf;
    }

    currentpos = 0;
    notecursor = -1;

    while (*pt) {
        int width;
        int c;
        int n = utf8_inspect(pt, &c, &width);
        if (c < ' ') {
            /* Control chars take up 2 spaces since we show them as ^X */
            width = 2;
        }

        if (currentpos == cursor_pos) {
            /* (e') wherever we output this character is where we want the cursor */
            DRL("<cn>");
            notecursor = 1;
        }

        if (displaycol + width > current->cols) {
            if (mlmode == 0) {
                /* In single line mode stop once we print as much as we can on one line */
                DRL("<slmode>", displaycol, width, current->cols);
                break;
            }
            /* need to wrap to the next line since it doesn't fit */
            refreshNewline(current);
            displaycol = 0;
            displayrow++;
        }

        if (notecursor == 1) {
            /* (e') Save this position as the current cursor position */
            cursorcol = displaycol;
            cursorrow = displayrow;
            notecursor = 0;
            DRL("<cursor>");
        }

        if (c < ' ') {
            outputControlChar(current, c + '@');
        }
        else {
            outputChars(current, pt, n);
        }
        displaycol += width;

        DRL_CHAR(pt);
        if (width != 1) {
            DRL("<w=%d>", width);
        }

        pt += n;
        currentpos++;
    }

    /* If we didn't see the cursor, it is at the current location */
    if (notecursor) {
        DRL("<cursor>");
        cursorcol = displaycol;
        cursorrow = displayrow;
    }

    DRL("\nafter buf: displaycol=%d, displayrow=%d, cursorcol=%d, cursorrow=%d\n", displaycol, displayrow, cursorcol, cursorrow);

    /* (f) show hints */
    hint = refreshShowHints(current, buf, current->cols - displaycol, 1);

    /* Remember how many many cols are available for insert optimisation */
    if (prompt == current->prompt && hint == 0) {
        current->colsright = current->cols - displaycol;
        current->colsleft = displaycol;
    }
    else {
        /* Can't optimise */
        current->colsright = 0;
        current->colsleft = 0;
    }
    DRL("\nafter hints: colsleft=%d, colsright=%d\n\n", current->colsleft, current->colsright);

    refreshEndChars(current);

    /* (g) move the cursor to the correct place */
    cursorUp(current, displayrow - cursorrow);
    setCursorPos(current, cursorcol);

    /* (h) Update the number of rows if larger, but never reduce this */
    if (displayrow >= current->nrows) {
        current->nrows = displayrow + 1;
    }
    /* And remember the row that the cursor is on */
    current->rpos = cursorrow;

    refreshEnd(current);

#ifdef DEBUG_REFRESHLINE
    fclose(dfh);
#endif
}

static void refreshLine(struct current *current)
{
    refreshLineAlt(current, current->prompt, sb_str(current->buf), current->pos);
}

static void set_current(struct current *current, const char *str)
{
    sb_clear(current->buf);
    sb_append(current->buf, str);
    current->pos = sb_chars(current->buf);
}

/**
 * Removes the char at 'pos'.
 *
 * Returns 1 if the line needs to be refreshed, 2 if not
 * and 0 if nothing was removed
 */
static int remove_char(struct current *current, int pos)
{
    if (pos >= 0 && pos < sb_chars(current->buf)) {
        int offset = utf8_index(sb_str(current->buf), pos);
        int nbytes = utf8_index(sb_str(current->buf) + offset, 1);
        int rc = 1;

        /* Now we try to optimise in the simple but very common case that:
         * - outputChars() can be used directly (not win32)
         * - we are removing the char at EOL
         * - the buffer is not empty
         * - there are columns available to the left
         * - the char being deleted is not a wide or utf-8 character
         * - no hints are being shown
         */
        if (current->output && current->pos == pos + 1 && current->pos == sb_chars(current->buf) && pos > 0) {
#ifdef USE_UTF8
            /* Could implement utf8_prev_len() but simplest just to not optimise this case */
            char last = sb_str(current->buf)[offset];
#else
            char last = 0;
#endif
            if (current->colsleft > 0 && (last & 0x80) == 0) {
                /* Have cols on the left and not a UTF-8 char or continuation */
                /* Yes, can optimise */
                current->colsleft--;
                current->colsright++;
                rc = 2;
            }
        }

        sb_delete(current->buf, offset, nbytes);

        if (current->pos > pos) {
            current->pos--;
        }
        if (rc == 2) {
            if (refreshShowHints(current, sb_str(current->buf), current->colsright, 0)) {
                /* A hint needs to be shown, so can't optimise after all */
                rc = 1;
            }
            else {
                /* optimised output */
                outputChars(current, "\b \b", 3);
            }
        }
        return rc;
        return 1;
    }
    return 0;
}

/**
 * Insert character 'ch' of length 'chbytes' at position 'pos'
 *
 * Note that ch must contain no more than one character
 * (i.e. consume no more than one character position).
 *
 * Returns 1 if the line needs to be refreshed, 2 if not
 * and 0 if nothing was inserted (no room)
 */
static int insert_char(struct current *current, int pos, const char *ch, int chbytes)
{
    int rc = 0;
    if (pos >= 0 && pos <= sb_chars(current->buf)) {
        /* Verify that it is a single character */
        int c;
        int width;
        int n = utf8_inspect(ch, &c, &width);
        assert(n == chbytes);

        rc = 1;

        /* Now we try to optimise in the simple but very common case that:
         * - outputChars() can be used directly (not win32)
         * - we are inserting at EOL
         * - there are enough columns available
         * - no hints are being shown
         */
        if (current->output && pos == current->pos && pos == sb_chars(current->buf)) {
            if (current->colsright > width) {
                /* Yes, can optimise */
                current->colsright -= width;
                current->colsleft -= width;
                rc = 2;
            }
        }
        /* Remember the old character count in case this does not increase
         * the character count
         */
        int oldchars = sb_chars(current->buf);
        sb_insert_chars(current->buf, pos, ch, chbytes);
        if (current->pos >= pos && oldchars != sb_chars(current->buf)) {
            current->pos++;
        }
        if (rc == 2) {
            if (refreshShowHints(current, sb_str(current->buf), current->colsright, 0)) {
                /* A hint needs to be shown, so can't optimise after all */
                rc = 1;
            }
            else {
                /* optimised output */
                outputChars(current, ch, n);
            }
        }
    }
    return rc;
}

/* Like insert_char but takes a unicode codepoint and converts it to utf-8 before inserting.
 * Returns the same as insert_char()
 */
static int insert_codepoint(struct current *current, int pos, int c)
{
    char buf[MAX_UTF8_LEN];
    int n = utf8_getchars(buf, c);
    int ret = insert_char(current, pos, buf, n);
    return ret;
}

/**
 * Captures up to 'n' characters starting at 'pos' for the cut buffer.
 *
 * This replaces any existing characters in the cut buffer.
 */
static void capture_chars(struct current *current, int pos, int nchars)
{
    if (pos >= 0 && (pos + nchars - 1) < sb_chars(current->buf)) {
        int offset = utf8_index(sb_str(current->buf), pos);
        int nbytes = utf8_index(sb_str(current->buf) + offset, nchars);

        if (nbytes > 0) {
            if (current->capture) {
                sb_clear(current->capture);
            }
            else {
                current->capture = sb_alloc();
            }
            sb_append_len(current->capture, sb_str(current->buf) + offset, nbytes);
        }
    }
}

/**
 * Removes up to 'n' characters at cursor position 'pos'.
 *
 * Returns 0 if no chars were removed or non-zero otherwise.
 */
static int remove_chars(struct current *current, int pos, int n)
{
    int removed = 0;

    /* First save any chars which will be removed */
    capture_chars(current, pos, n);

    while (n-- && remove_char(current, pos)) {
        removed++;
    }
    return removed;
}
/**
 * Inserts the characters (string) 'chars' at the cursor position 'pos'.
 *
 * Returns 0 if no chars were inserted or non-zero otherwise.
 *
 */
static int insert_chars(struct current *current, int pos, const char *chars)
{
    int inserted = 0;

    /* We insert one "character" at a time, which may include multiple codepoints */

    while (*chars) {
        /* Get a whole character */
        int bytes = utf8_char_bytes(chars, -1);
        if (insert_char(current, pos, chars, bytes) == 0) {
            break;
        }
        inserted++;
        pos++;
        chars += bytes;
    }
    return inserted;
}

static int skip_space_nonspace(struct current *current, int dir, int check_is_space)
{
    int moved = 0;
    /* need to reimplement this taking into account glyths/grapheme clusters */
    int checkoffset = (dir < 0) ? -1 : 0;
    int limit = (dir < 0) ? 0 : sb_chars(current->buf);
    while (current->pos != limit && (get_char(current, current->pos + checkoffset) == ' ') == check_is_space) {
        current->pos += dir;
        moved++;
    }
    return moved;
}

static int skip_space(struct current *current, int dir)
{
    return skip_space_nonspace(current, dir, 1);
}

static int skip_nonspace(struct current *current, int dir)
{
    return skip_space_nonspace(current, dir, 0);
}

static void set_history_index(struct current *current, int new_index)
{
    if (history_len > 1) {
        /* Update the current history entry before to
         * overwrite it with the next one. */
        free(history[history_len - 1 - history_index]);
        history[history_len - 1 - history_index] = strdup(sb_str(current->buf));
        /* Show the new entry */
        history_index = new_index;
        if (history_index < 0) {
            history_index = 0;
        } else if (history_index >= history_len) {
            history_index = history_len - 1;
        } else {
            set_current(current, history[history_len - 1 - history_index]);
            refreshLine(current);
        }
    }
}

/**
 * Returns the keycode to process, or 0 if none.
 */
static int reverseIncrementalSearch(struct current *current)
{
    /* Display the reverse-i-search prompt and process chars */
    char rbuf[50];
    char rprompt[80];
    int rchars = 0;
    int rlen = 0;
    int searchpos = history_len - 1;
    int c;

    rbuf[0] = 0;
    while (1) {
        int n = 0;
        const char *p = NULL;
        int skipsame = 0;
        int searchdir = -1;

        snprintf(rprompt, sizeof(rprompt), "(reverse-i-search)'%s': ", rbuf);
        refreshLineAlt(current, rprompt, sb_str(current->buf), current->pos);
        c = fd_read(current);
        if (c == ctrl('H') || c == CHAR_DELETE) {
            if (rchars) {
                int p_ind = utf8_index(rbuf, --rchars);
                rbuf[p_ind] = 0;
                rlen = strlen(rbuf);
            }
            continue;
        }
#ifdef USE_TERMIOS
        if (c == CHAR_ESCAPE) {
            c = check_special(current);
        }
#endif
        if (c == ctrl('R')) {
            /* Search for the previous (earlier) match */
            if (searchpos > 0) {
                searchpos--;
            }
            skipsame = 1;
        }
        else if (c == ctrl('S')) {
            /* Search for the next (later) match */
            if (searchpos < history_len) {
                searchpos++;
            }
            searchdir = 1;
            skipsame = 1;
        }
        else if (c == ctrl('P') || c == SPECIAL_UP) {
            /* Exit Ctrl-R mode and go to the previous history line from the current search pos */
            set_history_index(current, history_len - searchpos);
            c = 0;
            break;
        }
        else if (c == ctrl('N') || c == SPECIAL_DOWN) {
            /* Exit Ctrl-R mode and go to the next history line from the current search pos */
            set_history_index(current, history_len - searchpos - 2);
            c = 0;
            break;
        }
        else if (c >= ' ' && c <= '~') {
            /* >= here to allow for null terminator */
            if (rlen >= (int)sizeof(rbuf) - MAX_UTF8_LEN) {
                continue;
            }

            n = utf8_getchars(rbuf + rlen, c);
            rlen += n;
            rchars++;
            rbuf[rlen] = 0;

            /* Adding a new char resets the search location */
            searchpos = history_len - 1;
        }
        else {
            /* Exit from incremental search mode */
            break;
        }

        /* Now search through the history for a match */
        for (; searchpos >= 0 && searchpos < history_len; searchpos += searchdir) {
            p = strstr(history[searchpos], rbuf);
            if (p) {
                /* Found a match */
                if (skipsame && strcmp(history[searchpos], sb_str(current->buf)) == 0) {
                    /* But it is identical, so skip it */
                    continue;
                }
                /* Copy the matching line and set the cursor position */
                history_index = history_len - 1 - searchpos;
                set_current(current,history[searchpos]);
                current->pos = utf8_charcount(history[searchpos], p - history[searchpos]);
                break;
            }
        }
        if (!p && n) {
            /* No match, so don't add it */
            rchars--;
            rlen -= n;
            rbuf[rlen] = 0;
        }
    }
    if (c == ctrl('G') || c == ctrl('C')) {
        /* ctrl-g terminates the search with no effect */
        set_current(current, "");
        history_index = 0;
        c = 0;
    }
    else if (c == ctrl('J')) {
        /* ctrl-j terminates the search leaving the buffer in place */
        history_index = 0;
        c = 0;
    }
    /* Go process the char normally */
    refreshLine(current);
    return c;
}

static int linenoiseEdit(struct current *current) {
    history_index = 0;

    refreshLine(current);

    while(1) {
        int c = fd_read(current);

#ifndef NO_COMPLETION
        /* Only autocomplete when the callback is set. It returns < 0 when
         * there was an error reading from fd. Otherwise it will return the
         * character that should be handled next. */
        if (c == '\t' && current->pos == sb_chars(current->buf) && completionCallback != NULL) {
            c = completeLine(current);
        }
#endif
        if (c == ctrl('R')) {
            /* reverse incremental search will provide an alternative keycode or 0 for none */
            c = reverseIncrementalSearch(current);
            /* go on to process the returned char normally */
        }

#ifdef USE_TERMIOS
        if (c == CHAR_ESCAPE) {   /* escape sequence */
            c = check_special(current);
        }
#endif
        if (c == -1) {
            /* Return on errors */
            return sb_len(current->buf);
        }

        switch(c) {
        case SPECIAL_NONE:
            break;
        case '\r':    /* enter/CR */
        case '\n':    /* LF */
            history_len--;
            free(history[history_len]);
            current->pos = sb_chars(current->buf);
            if (mlmode || hintsCallback) {
                showhints = 0;
                refreshLine(current);
                showhints = 1;
            }
            return sb_len(current->buf);
        case ctrl('C'):     /* ctrl-c */
            errno = EAGAIN;
            return -1;
        case ctrl('Z'):     /* ctrl-z */
#ifdef SIGTSTP
            /* send ourselves SIGSUSP */
            disableRawMode(current);
            raise(SIGTSTP);
            /* and resume */
            enableRawMode(current);
            refreshLine(current);
#endif
            continue;
        case CHAR_DELETE:   /* backspace */
        case ctrl('H'):
            if (remove_char(current, current->pos - 1) == 1) {
                refreshLine(current);
            }
            break;
        case ctrl('D'):     /* ctrl-d */
            if (sb_len(current->buf) == 0) {
                /* Empty line, so EOF */
                history_len--;
                free(history[history_len]);
                return -1;
            }
            /* Otherwise fall through to delete char to right of cursor */
            /* fall-thru */
        case SPECIAL_DELETE:
            if (remove_char(current, current->pos) == 1) {
                refreshLine(current);
            }
            break;
        case SPECIAL_INSERT:
            /* Ignore. Expansion Hook.
             * Future possibility: Toggle Insert/Overwrite Modes
             */
            break;
        case meta('b'):    /* meta-b, move word left */
            if (skip_nonspace(current, -1)) {
                refreshLine(current);
            }
            else if (skip_space(current, -1)) {
                skip_nonspace(current, -1);
                refreshLine(current);
            }
            break;
        case meta('f'):    /* meta-f, move word right */
            if (skip_space(current, 1)) {
                refreshLine(current);
            }
            else if (skip_nonspace(current, 1)) {
                skip_space(current, 1);
                refreshLine(current);
            }
            break;
        case ctrl('W'):    /* ctrl-w, delete word at left. save deleted chars */
            /* eat any spaces on the left */
            {
                int pos = current->pos;
                while (pos > 0 && get_char(current, pos - 1) == ' ') {
                    pos--;
                }

                /* now eat any non-spaces on the left */
                while (pos > 0 && get_char(current, pos - 1) != ' ') {
                    pos--;
                }

                if (remove_chars(current, pos, current->pos - pos)) {
                    refreshLine(current);
                }
            }
            break;
        case ctrl('T'):    /* ctrl-t */
            if (current->pos > 0 && current->pos <= sb_chars(current->buf)) {
                /* If cursor is at end, transpose the previous two chars */
                int fixer = (current->pos == sb_chars(current->buf));
                int offset;
                int n = get_char_offset(current, current->pos - fixer, &offset);
                assert(n > 0);
                /* We need to copy this char before we remove it so we can reinsert it
                 * This size should be good enough for all practical purposes. If not, do nothing
                 */
                char buf[32];
                if (n <= (int)sizeof(buf)) {
                    memcpy(buf, sb_str(current->buf) + offset, n);
                    remove_char(current, current->pos - fixer);
                    insert_char(current, current->pos - 1, buf, n);
                    refreshLine(current);
                }
            }
            break;
        case ctrl('V'):    /* ctrl-v */
            /* Insert the ^V first */
            if (insert_codepoint(current, current->pos, c)) {
                refreshLine(current);
                /* Now wait for the next char. Can insert anything except \0 */
                c = fd_read(current);

                /* Remove the ^V first */
                remove_char(current, current->pos - 1);
                if (c > 0) {
                    /* Insert the actual char, can't be error or null */
                    insert_codepoint(current, current->pos, c);
                }
                refreshLine(current);
            }
            break;
        case ctrl('B'):
        case SPECIAL_LEFT:
            if (current->pos > 0) {
                current->pos--;
                refreshLine(current);
            }
            break;
        case ctrl('F'):
        case SPECIAL_RIGHT:
            if (current->pos < sb_chars(current->buf)) {
                current->pos++;
                refreshLine(current);
            }
            break;
        case SPECIAL_PAGE_UP: /* move to start of history */
          set_history_index(current, history_len - 1);
          break;
        case SPECIAL_PAGE_DOWN: /* move to 0 == end of history, i.e. current */
          set_history_index(current, 0);
          break;
        case ctrl('P'):
        case SPECIAL_UP:
            set_history_index(current, history_index + 1);
            break;
        case ctrl('N'):
        case SPECIAL_DOWN:
            set_history_index(current, history_index - 1);
            break;
        case ctrl('A'): /* Ctrl+a, go to the start of the line */
        case SPECIAL_HOME:
            current->pos = 0;
            refreshLine(current);
            break;
        case ctrl('E'): /* ctrl+e, go to the end of the line */
        case SPECIAL_END:
            current->pos = sb_chars(current->buf);
            refreshLine(current);
            break;
        case ctrl('U'): /* Ctrl+u, delete to beginning of line, save deleted chars. */
            if (remove_chars(current, 0, current->pos)) {
                refreshLine(current);
            }
            break;
        case ctrl('K'): /* Ctrl+k, delete from current to end of line, save deleted chars. */
            if (remove_chars(current, current->pos, sb_chars(current->buf) - current->pos)) {
                refreshLine(current);
            }
            break;
        case ctrl('Y'): /* Ctrl+y, insert saved chars at current position */
            if (current->capture && insert_chars(current, current->pos, sb_str(current->capture))) {
                refreshLine(current);
            }
            break;
        case ctrl('L'): /* Ctrl+L, clear screen */
            linenoiseClearScreen();
            /* Force recalc of window size for serial terminals */
            current->cols = 0;
            current->rpos = 0;
            refreshLine(current);
            break;
        default:
            if (c >= meta('a') && c <= meta('z')) {
                /* Don't insert meta chars that are not bound */
                break;
            }
            /* Only tab is allowed without ^V */
            if (c == '\t' || c >= ' ') {
                if (insert_codepoint(current, current->pos, c) == 1) {
                    refreshLine(current);
                }
            }
            break;
        }
    }
    return sb_len(current->buf);
}

int linenoiseColumns(void)
{
    struct current current;
    current.output = NULL;
    enableRawMode (&current);
    getWindowSize (&current);
    disableRawMode (&current);
    return current.cols;
}

/**
 * Reads a line from the file handle (without the trailing NL or CRNL)
 * and returns it in a stringbuf.
 * Returns NULL if no characters are read before EOF or error.
 *
 * Note that the character count will *not* be correct for lines containing
 * utf8 sequences. Do not rely on the character count.
 */
static stringbuf *sb_getline(FILE *fh)
{
    stringbuf *sb = sb_alloc();
    int c;
    int n = 0;

    while ((c = getc(fh)) != EOF) {
        char ch;
        n++;
        if (c == '\r') {
            /* CRLF -> LF */
            continue;
        }
        if (c == '\n' || c == '\r') {
            break;
        }
        ch = c;
        /* ignore the effect of character count for partial utf8 sequences */
        sb_append_len(sb, &ch, 1);
    }
    if (n == 0 || sb->data == NULL) {
        sb_free(sb);
        return NULL;
    }
    return sb;
}

char *linenoiseWithInitial(const char *prompt, const char *initial)
{
    int count;
    struct current current;
    stringbuf *sb;

    memset(&current, 0, sizeof(current));

    if (enableRawMode(&current) == -1) {
        printf("%s", prompt);
        fflush(stdout);
        sb = sb_getline(stdin);
        if (sb && !fd_isatty(&current)) {
            printf("%s\n", sb_str(sb));
            fflush(stdout);
        }
    }
    else {
        current.buf = sb_alloc();
        current.pos = 0;
        current.nrows = 1;
        current.prompt = prompt;

        /* The latest history entry is always our current buffer */
        linenoiseHistoryAdd(initial);
        set_current(&current, initial);

        count = linenoiseEdit(&current);

        disableRawMode(&current);
        printf("\n");

        sb_free(current.capture);
        if (count == -1) {
            sb_free(current.buf);
            return NULL;
        }
        sb = current.buf;
    }
    return sb ? sb_to_string(sb) : NULL;
}

char *linenoise(const char *prompt)
{
    return linenoiseWithInitial(prompt, "");
}

/* Using a circular buffer is smarter, but a bit more complex to handle. */
static int linenoiseHistoryAddAllocated(char *line) {

    if (history_max_len == 0) {
notinserted:
        free(line);
        return 0;
    }
    if (history == NULL) {
        history = (char **)calloc(sizeof(char*), history_max_len);
    }

    /* do not insert duplicate lines into history */
    if (history_len > 0 && strcmp(line, history[history_len - 1]) == 0) {
        goto notinserted;
    }

    if (history_len == history_max_len) {
        free(history[0]);
        memmove(history,history+1,sizeof(char*)*(history_max_len-1));
        history_len--;
    }
    history[history_len] = line;
    history_len++;
    return 1;
}

int linenoiseHistoryAdd(const char *line) {
    return linenoiseHistoryAddAllocated(strdup(line));
}

int linenoiseHistoryGetMaxLen(void) {
    return history_max_len;
}

int linenoiseHistorySetMaxLen(int len) {
    char **newHistory;

    if (len < 1) return 0;
    if (history) {
        int tocopy = history_len;

        newHistory = (char **)calloc(sizeof(char*), len);

        /* If we can't copy everything, free the elements we'll not use. */
        if (len < tocopy) {
            int j;

            for (j = 0; j < tocopy-len; j++) free(history[j]);
            tocopy = len;
        }
        memcpy(newHistory,history+(history_len-tocopy), sizeof(char*)*tocopy);
        free(history);
        history = newHistory;
    }
    history_max_len = len;
    if (history_len > history_max_len)
        history_len = history_max_len;
    return 1;
}

/* Save the history in the specified file. On success 0 is returned
 * otherwise -1 is returned. */
int linenoiseHistorySave(const char *filename) {
    FILE *fp = fopen(filename,"w");
    int j;

    if (fp == NULL) return -1;
    for (j = 0; j < history_len; j++) {
        const char *str = history[j];
        /* Need to encode backslash, nl and cr */
        while (*str) {
            if (*str == '\\') {
                fputs("\\\\", fp);
            }
            else if (*str == '\n') {
                fputs("\\n", fp);
            }
            else if (*str == '\r') {
                fputs("\\r", fp);
            }
            else {
                fputc(*str, fp);
            }
            str++;
        }
        fputc('\n', fp);
    }

    fclose(fp);
    return 0;
}

/* Load the history from the specified file.
 *
 * If the file does not exist or can't be opened, no operation is performed
 * and -1 is returned.
 * Otherwise 0 is returned.
 */
int linenoiseHistoryLoad(const char *filename) {
    FILE *fp = fopen(filename,"r");
    stringbuf *sb;

    if (fp == NULL) return -1;

    while ((sb = sb_getline(fp)) != NULL) {
        /* Take the stringbuf and decode backslash escaped values */
        char *buf = sb_to_string(sb);
        char *dest = buf;
        const char *src;

        for (src = buf; *src; src++) {
            char ch = *src;

            if (ch == '\\') {
                src++;
                if (*src == 'n') {
                    ch = '\n';
                }
                else if (*src == 'r') {
                    ch = '\r';
                } else {
                    ch = *src;
                }
            }
            *dest++ = ch;
        }
        *dest = 0;

        linenoiseHistoryAddAllocated(buf);
    }
    fclose(fp);
    return 0;
}

/* Provide access to the history buffer.
 *
 * If 'len' is not NULL, the length is stored in *len.
 */
char **linenoiseHistory(int *len) {
    if (len) {
        *len = history_len;
    }
    return history;
}
